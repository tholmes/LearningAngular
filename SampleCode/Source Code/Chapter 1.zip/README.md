### Pre-requisites
* [NodeJS](http://nodejs.org/)
* [GIT](http://git-scm.com/downloads)

### Using the Code
To utilize this companion code, inside the directory for each step please run `npm install && bower install` so that all required modules and front-end dependencies can be downloaded.

Afterwords, running `grunt serve` inside the directory for a given step will open a new browser tab containing the StockDog application in its current state as outlined in the book.
